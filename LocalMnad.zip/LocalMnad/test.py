import numpy as np
from collections import OrderedDict  # 有序的字典
import os
import glob  # glob模块可以使用Unix shell风格的通配符匹配符合特定格式的文件和文件夹，跟windows的文件搜索功能差不多。
import cv2
import torch
import torch.utils.data as data
import torch.nn.functional as F
videos = OrderedDict()
dirs = '/home/lj/MNAD/MNAD-master/dataset/ped2/training/frames/16'
frames = glob.glob(os.path.join(dirs, '*'))
index = 0
image = cv2.imread("/home/lj/MNAD/MNAD-master/dataset/ped2/training/frames/16/097.jpg")
# print(image.shape)
# ac = np.zeros((240, 360, 3))
path0 = "/home/lj/MNAD/MNAD-master/dataset/ped2/training/frames/16/000.jpg"
path1 = "/home/lj/MNAD/MNAD-master/dataset/ped2/training/frames/16/001.jpg"
path2 = "/home/lj/MNAD/MNAD-master/dataset/ped2/training/frames/16/002.jpg"
delta0 = cv2.imread(path0) - cv2.imread(path1)
delta0 = np.maximum(delta0, -delta0)
index1 = np.where(delta0 > 20)
index2 = np.where(delta0 < 20)
delta0[index1] = 255
delta0[index2] = 0
delta1 = cv2.imread(path2) - cv2.imread(path1)
delta1 = np.maximum(delta1, -delta1)
lamda = delta1 - delta0
lamda = np.maximum(lamda, -lamda)
cv2.imwrite("/home/lj/delta0.jpg", delta0)
cv2.imwrite("/home/lj/delta1.jpg", delta1)
cv2.imwrite("/home/lj/lamda0.jpg", lamda)







# loss_mse = torch.nn.MSELoss()
# loss = torch.nn.TripletMarginLoss(margin=1.0)
# query_reshape = torch.tensor([[31.0], [2.0], [13.0]])
# pos = torch.tensor([[4.0], [85.0], [56.0]])
# neg = torch.tensor([[7.0], [8.0], [19.0]])
# gathering_loss = loss(query_reshape, pos, neg)
# top1_loss = loss_mse(query_reshape, pos.detach())
# print(top1_loss)
# a = torch.linspace(1, 6, steps=6)
# a = a.view(2, 3)
# print(a)
# score_query = F.softmax(a, dim=0)
# print(score_query)
# image_decoded = cv2.imread("/home/lj/MNAD/MNAD-master/dataset/ped2/training/frames/06/040.jpg")
# ten = torch.from_numpy(image_decoded).float()
# print(ten)
# ten = F.normalize(ten, 2)
# res = ten.numpy() * 255.0
# cv2.imwrite("/home/lj/res1.jpg", res)
# torch.nn.TripletMarginLoss()

# b = torch.Tensor([1, 2, 3, 4])
# a = torch.Tensor([2, 3, 4, 5])
# c = torch.sqrt(((a - b) ** 2).sum()).unsqueeze(0)
# d = torch.sqrt(((a - b) ** 2).sum())
# print(d.shape)
# print(d)
# print(c.shape)
# print(c)
# x = torch.rand(2, 3)
# print(x)
# result_cpu = (6 - 1) * x + 1
# print(result_cpu)
# a = torch.Tensor([1, 2, 3])
# print(a.shape)
# log_dir = os.path.join('./exp', "args.dataset_type", "args.exp_dir")
# print(log_dir)
# a = np.array([[1,2,3],[4,5,6]])
# print(a)
# b = np.array([[11,22,33],[44,55,66]])
# c = np.array([[111,222,333],[444,555,666]])
# e = [a, b, c]
# d = np.concatenate(e,axis=0)  # 默认情况下，axis=0可以不写
# print(d)

# dirs = '/home/lj/MNAD/MNAD-master/dataset/ped2/training/frames/16'
# selfvideos = OrderedDict()
# videos = glob.glob(os.path.join(dirs, '*'))
# print(videos)
#
# image_decoded = cv2.imread("/home/lj/MNAD/MNAD-master/dataset/ped2/training/frames/06/040.jpg")
# print(image_decoded.shape)