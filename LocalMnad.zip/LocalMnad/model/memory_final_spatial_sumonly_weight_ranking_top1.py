import torch
import torch.autograd as ag
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import math
import functools
import random
from torch.nn import functional as F


def random_uniform(shape, low, high, cuda):
    x = torch.rand(*shape)  # 一个*就可以在传参的时候传入列表，random_uniform((2, 4),……) = x = torch.rand(2, 4)
    result_cpu = (high - low) * x + low
    if cuda:
        return result_cpu.cuda()
    else:
        return result_cpu


def distance(a, b):
    return torch.sqrt(((a - b) ** 2).sum()).unsqueeze(0)


def distance_batch(a, b):
    bs, _ = a.shape  #
    result = distance(a[0], b)
    for i in range(bs-1):
        result = torch.cat((result, distance(a[i], b)), 0)
    return result


def multiply(x):  # to flatten matrix into a vector
    return functools.reduce(lambda x, y: x*y, x, 1)


def flatten(x):
    """ Flatten matrix into a vector """
    count = multiply(x.size())
    return x.resize_(count)


def index(batch_size, x):
    idx = torch.arange(0, batch_size).long() 
    idx = torch.unsqueeze(idx, -1)
    return torch.cat((idx, x), dim=1)


def MemoryLoss(memory):
    m, d = memory.size()
    memory_t = torch.t(memory)
    similarity = (torch.matmul(memory, memory_t))/2 + 1/2 # 30X30
    identity_mask = torch.eye(m).cuda()
    sim = torch.abs(similarity - identity_mask)
    
    return torch.sum(sim)/(m*(m-1))


class Memory(nn.Module):
    # memory_size = 10, feature_dim = 512, key_dim = 512, temp_update = 0.1, temp_gather=0.1
    def __init__(self, memory_size, feature_dim, key_dim,  temp_update, temp_gather):
        super(Memory, self).__init__()
        # Constants
        self.memory_size = memory_size
        self.feature_dim = feature_dim
        self.key_dim = key_dim
        self.temp_update = temp_update
        self.temp_gather = temp_gather
        
    def hard_neg_mem(self, mem, i):
        similarity = torch.matmul(mem, torch.t(self.keys_var))
        similarity[:, i] = -1
        _, max_idx = torch.topk(similarity, 1, dim=1)
        return self.keys_var[max_idx]

    def random_pick_memory(self, mem, max_indices):
        m, d = mem.size()
        output = []
        for i in range(m):
            flattened_indices = (max_indices == i).nonzero()
            a, _ = flattened_indices.size()
            if a != 0:
                number = np.random.choice(a, 1)
                output.append(flattened_indices[number, 0])
            else:
                output.append(-1)

        return torch.tensor(output)
    
    def get_update_query(self, mem, max_indices, update_indices, score, query, train):
        
        m, d = mem.size()
        if train:
            query_update = torch.zeros((m, d)).cuda()
            # random_update = torch.zeros((m,d)).cuda()
            for i in range(m):
                idx = torch.nonzero(max_indices.squeeze(1) == i)
                a, _ = idx.size()
                if a != 0:
                    query_update[i] = torch.sum(((score[idx, i] / torch.max(score[:, i])) * query[idx].squeeze(1)), dim=0)
                else:
                    query_update[i] = 0 

            return query_update 
    
        else:
            query_update = torch.zeros((m, d)).cuda()
            for i in range(m):
                idx = torch.nonzero(max_indices.squeeze(1) == i)
                a, _ = idx.size()
                if a != 0:
                    query_update[i] = torch.sum(((score[idx, i] / torch.max(score[:, i])) * query[idx].squeeze(1)), dim=0)
                else:
                    query_update[i] = 0 
            
            return query_update

    def get_score(self, mem, query):
        bs, h, w, d = query.size()
        m, d = mem.size()
        
        score = torch.matmul(query, torch.t(mem))  # b X h X w X m  batch里所有的query和m个item的内积(相似度得分)
        score = score.view(bs * h * w, m)  # 本来上面的结果size是很复杂的，但是我们需要的只是，宽=所有query个，长=所有item个。
        
        score_query = F.softmax(score, dim=0)  # 某一个item和所有的quary的得分
        score_memory = F.softmax(score, dim=1)  # 同一个quary和所有的item的得分
        
        return score_query, score_memory
    
    def forward(self, query, keys, train=True):

        batch_size, dims, h, w = query.size()  # (b,d,h,w)
        query = F.normalize(query, dim=1)
        query = query.permute(0, 2, 3, 1)  # (b,h,w,d)
        
        # train
        if train:
            # losses  query和第一近以及第二近的三元距离，query和最近的item的距离
            separateness_loss, compactness_loss = self.gather_loss(query, keys, train)
            # read    综合items的query，某个item和所有的query关联度，某个query和所有的item关联度
            updated_query, softmax_score_query, softmax_score_memory = self.read(query, keys)
            # update
            updated_memory = self.update(query, keys, train)
            
            return updated_query, updated_memory, softmax_score_query, softmax_score_memory, separateness_loss, compactness_loss
        
        # test
        else:
            # loss
            compactness_loss, query_re, top1_keys, keys_ind = self.gather_loss(query, keys, train)
            # read
            updated_query, softmax_score_query, softmax_score_memory = self.read(query, keys)
            # update
            updated_memory = keys
            return updated_query, updated_memory, softmax_score_query, softmax_score_memory, query_re, top1_keys, keys_ind, compactness_loss

    """
        query:(b,h,w,d)
        keys:(m,d)
    """
    def update(self, query, keys, train):
        batch_size, h, w, dims = query.size()  # b X h X w X d
        # 某个item和所有query的相关度， 某个query和所有item的相关度 (b * h * w, m)
        softmax_score_query, softmax_score_memory = self.get_score(keys, query)
        query_reshape = query.contiguous().view(batch_size*h*w, dims)
        _, gathering_indices = torch.topk(softmax_score_memory, 1, dim=1)  # 得到的是和q1最相关的m的idx,和q2最相关的m的idx
        _, updating_indices = torch.topk(softmax_score_query, 1, dim=0)  # 得到的是和m1最相关的q的idx, 和m2最相关的q的idx,

        if train:
            query_update = self.get_update_query(keys, gathering_indices, updating_indices, softmax_score_query, query_reshape, train)
            updated_memory = F.normalize(query_update + keys, dim=1)
        else:
            query_update = self.get_update_query(keys, gathering_indices, updating_indices, softmax_score_query , query_reshape, train)
            updated_memory = F.normalize(query_update + keys, dim=1)
        
        return updated_memory.detach()

    def pointwise_gather_loss(self, query_reshape, keys, gathering_indices, train):
        n, dims = query_reshape.size()  # (b X h X w) X d
        loss_mse = torch.nn.MSELoss(reduction='none')
        
        pointwise_loss = loss_mse(query_reshape, keys[gathering_indices].squeeze(1).detach())
                
        return pointwise_loss
        
    def gather_loss(self, query, keys, train):
        batch_size, h, w, dims = query.size()  # b X h X w X d
        if train:
            loss = torch.nn.TripletMarginLoss(margin=1.0)
            loss_mse = torch.nn.MSELoss()
            softmax_score_query, softmax_score_memory = self.get_score(keys, query)
        
            query_reshape = query.contiguous().view(batch_size*h*w, dims)

            # gathering_indices的shape应该是(b*h*w*d, 2)
            _, gathering_indices = torch.topk(softmax_score_memory, 2, dim=1)  # 得到和每个q，最近的2个item的idx
        
            # 1st, 2nd closest memories   keys是所有的memory items和idx, 得到的应该是(b X h X w，d)
            pos = keys[gathering_indices[:, 0]]
            neg = keys[gathering_indices[:, 1]]

            top1_loss = loss_mse(query_reshape, pos.detach())  # 定义query和最近的item的loss   (b*h*w*d, 1)
            gathering_loss = loss(query_reshape, pos.detach(), neg.detach())  # 定义三元距离
            
            return gathering_loss, top1_loss
            
        else:
            loss_mse = torch.nn.MSELoss()
        
            softmax_score_query, softmax_score_memory = self.get_score(keys, query)
        
            query_reshape = query.contiguous().view(batch_size*h*w, dims)
        
            _, gathering_indices = torch.topk(softmax_score_memory, 1, dim=1)  # 得到和每个q，最近的item。
        
            gathering_loss = loss_mse(query_reshape, keys[gathering_indices].squeeze(1).detach())
            
            return gathering_loss, query_reshape, keys[gathering_indices].squeeze(1).detach(), gathering_indices[:, 0]

    # 返回的是:
    #        1、综合所有items和自身关联度的query(b, d, h, w)
    #        2、某个items和所有query的相关度(b * h * w, m)
    #        3、某个query和所有items的相关度(b * h * w, m)
    def read(self, query, updated_memory):
        batch_size, h, w, dims = query.size()  # b X h X w X d 即 batch_size, height, width, channel[dims]【RGB即3维】
        # 某个item和所有的query，某个query和所有的item
        softmax_score_query, softmax_score_memory = self.get_score(updated_memory, query)

        query_reshape = query.contiguous().view(batch_size*h*w, dims)

        # 根据某个query和所有的items的相关度，综合所有的item得出该query的
        # .detach()：Returns a new Variable, detached from the current graph
        #                                 （bs * h * w, m）                （m, d）
        concat_memory = torch.matmul(softmax_score_memory.detach(), updated_memory)

        # 将原始的query和结合了所有item信息的query concatnate在一起
        updated_query = torch.cat((query_reshape, concat_memory), dim=1)  # (b X h X w) X 2d
        updated_query = updated_query.view(batch_size, h, w, 2*dims)  #（b, h, w, d）
        updated_query = updated_query.permute(0, 3, 1, 2)  # (b, d, h, w)
        
        return updated_query, softmax_score_query, softmax_score_memory

