import numpy as np
from collections import OrderedDict  # 有序的字典
import os
import glob  # glob模块可以使用Unix shell风格的通配符匹配符合特定格式的文件和文件夹，跟windows的文件搜索功能差不多。
import cv2
import torch.utils.data as data


rng = np.random.RandomState(2020)

def np_load_frame(filename, resize_height, resize_width):
    """
    Load image path and convert it to numpy.ndarray. Notes that the color channels are BGR and the color space
    is normalized from [0, 255] to [-1, 1].

    :param filename: the full path of image
    :param resize_height: resized height
    :param resize_width: resized width
    :return: numpy.ndarray
    """
    image_decoded = cv2.imread(filename)  # 为多维度的np数组
    image_resized = cv2.resize(image_decoded, (resize_width, resize_height))
    image_resized = image_resized.astype(dtype=np.float32)  # 将多维数组转换为float32
    image_resized = (image_resized / 127.5) - 1.0
    return image_resized



"""重写了data.Dataset"""
class DataLoader(data.Dataset):
    def __init__(self, video_folder, transform, resize_height, resize_width, time_step=4, num_pred=1):
        self.dir = video_folder
        self.transform = transform
        self.videos = OrderedDict()
        self._resize_height = resize_height
        self._resize_width = resize_width
        self._time_step = time_step
        self._num_pred = num_pred
        self.setup()
        self.samples = self.get_all_samples()
        
    """setup()的处理：
    self.videos是一个有序的字典：{'001' : {
                                          path : str=「001的路径」,
                                          frame : list= [001文件夹下所有的jpg, 再进行排序],
                                          length ：int= frame的数量,
                                       }, 
                               '002' : {
                                          path : str=「002的路径」,
                                          frame : list= [002文件夹下所有的jpg且每个jpg都是全路径, 再进行排序],
                                          length : int= frame的数量,
                                        }
                               }
    """
    def setup(self):
        videos = glob.glob(os.path.join(self.dir, '*'))
        for video in sorted(videos):
            video_name = video.split('/')[-1]
            self.videos[video_name] = {}
            self.videos[video_name]['path'] = video
            self.videos[video_name]['frame'] = glob.glob(os.path.join(video, '*.jpg'))
            self.videos[video_name]['frame'].sort()
            self.videos[video_name]['length'] = len(self.videos[video_name]['frame'])
            
    """某段视频都减去n帧后，将所有视频的帧汇聚起来"""
    def get_all_samples(self):
        frames = []
        videos = glob.glob(os.path.join(self.dir, '*'))
        for video in sorted(videos):
            video_name = video.split('/')[-1]
            for i in range(len(self.videos[video_name]['frame'])-self._time_step):
                frames.append(self.videos[video_name]['frame'][i])
        # allsamples_len = len(frames)
        # print("allsamples_len = ", allsamples_len)
        # print("get_all_samples_sample[800]=", frames[800])
        # >> /home/lj/MNAD/MNAD-master/dataset/ped2/training/frames/06/040.jpg
        return frames               
            
        
    def __getitem__(self, index):
        video_name = self.samples[index].split('/')[-2]
        frame_name = int(self.samples[index].split('/')[-1].split('.')[-2])
        
        batch = []
        # 默认_time_step=4 _num_pred=1：输入4个连续的帧，预测第5个帧
        for i in range(self._time_step+self._num_pred):
            # 对图像进行了调整和归一化
            image = np_load_frame(self.videos[video_name]['frame'][frame_name+i], self._resize_height, self._resize_width)
            if self.transform is not None:
                batch.append(self.transform(image))
        # batch里有m个元素,每一个元素都是一个比如(4,4,3)的多维数组，下面按行拼接，最后生成的多维数组就有4m行
        # 具体来讲，getitem每次返回的是5个帧的图像
        return np.concatenate(batch, axis=0)

    def __len__(self):
        return len(self.samples)
